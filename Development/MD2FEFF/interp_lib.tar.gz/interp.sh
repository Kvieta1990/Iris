#!/bin/bash
#
mkdir temp
cd temp
rm *
/home/ai-peng/Softwares/Scripts/Fortran/f90split ../interp.f90
#
for FILE in `ls -1 *.f90`;
do
  gfortran -c $FILE
  if [ $? -ne 0 ]; then
    echo "Errors compiling " $FILE
    exit
  fi
done
rm *.f90
#
ar qc libinterp.a *.o
rm *.o
#
mv libinterp.a /home/ai-peng/Softwares/Scripts/Fortran/lib
cd ..
rmdir temp
#
echo "Library installed as /home/ai-peng/Softwares/Scripts/Fortran/lib/libinterp.a"
