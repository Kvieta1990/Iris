********************************************************************************
This directory contains the Fortran interpolation library.
********************************************************************************
The source of this library can be found following the link:

https://people.sc.fsu.edu/~jburkardt/f_src/interp/interp.html

The liscence and reference information can also be found in the above link.
********************************************************************************
To install the library, just run the script 'interp.sh' in current directory.
********************************************************************************
For the installation, the 'f90split' program is needed, which is also included
in current directory. The path specifying where 'f90split' is located should be
changed in the 'interp.sh' script (should be in the 6th line).
********************************************************************************
The installation directory specified in the 'interp.sh' script (should be in the
21st line) should also be changed to wherever the user prefers on specific 
machine.
********************************************************************************
Yuanpeng Zhang @ 22-May-2016
School of Physics and Astronomy
Queen Mary, University of London
********************************************************************************
